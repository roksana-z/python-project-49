### Hexlet tests and linter status:
[![Actions Status](https://github.com/roksana-z/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/roksana-z/python-project-49/actions)
<a href="https://codeclimate.com/github/roksana-z/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/7a141571bc6aa90cd533/maintainability" /></a>