import random


def get_correct_answer(*args):
    progression, hidden_position = args[0]
    return progression[hidden_position]

def show_question(progression, position_of_hidden_number):
    progression[position_of_hidden_number] = '..'
    return ' '.join(progression)

def generate_arithmetic_progression(start_point, step, progression_length):
    progression = []
    for i in range(progression_length):
        progression.append(start_point + i*step)
    return progression

def get_question():
    progression_length = 10
    step = random.randint(1, 10)
    start_point = random.randint(1, 10)
    position_of_hidden_number = (0, progression_length - 1)
    progression = generate_arithmetic_progression(start_point, step, progression_length)
    return (progression, position_of_hidden_number)

def show_game_description():
    print('Find the greatest common divisor of given numbers.')